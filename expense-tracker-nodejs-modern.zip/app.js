const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const path = require('path');
const app = express();

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'abcd@123',
  database: 'expense_tracker'
});

connection.connect(err => {
  if (err) throw err;
  console.log('Connected to MySQL');
});

app.use(session({
  secret: 'secret',
  resave: true,
  saveUninitialized: true
}));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');

app.get('/', (req, res) => res.redirect('/login'));
app.get('/login', (req, res) => res.render('login'));
app.get('/register', (req, res) => res.render('register'));
app.get('/dashboard', (req, res) => {
  if (req.session.loggedin) {
    connection.query('SELECT * FROM expenses WHERE user_id = ?', [req.session.user_id], (err, results) => {
      res.render('dashboard', { username: req.session.username, expenses: results });
    });
  } else {
    res.redirect('/login');
  }
});

app.post('/auth', (req, res) => {
  const { username, password } = req.body;
  connection.query('SELECT * FROM users WHERE username = ? AND password = ?', [username, password], (err, results) => {
    if (results.length > 0) {
      req.session.loggedin = true;
      req.session.username = username;
      req.session.user_id = results[0].id;
      res.redirect('/dashboard');
    } else {
      res.send('Incorrect Username and/or Password!');
    }
  });
});

app.post('/register', (req, res) => {
  const { username, password } = req.body;
  connection.query('INSERT INTO users (username, password) VALUES (?, ?)', [username, password], err => {
    if (err) throw err;
    res.redirect('/login');
  });
});

app.post('/add-expense', (req, res) => {
  const { title, amount } = req.body;
  connection.query('INSERT INTO expenses (user_id, title, amount) VALUES (?, ?, ?)', [req.session.user_id, title, amount], err => {
    if (err) throw err;
    res.redirect('/dashboard');
  });
});

app.listen(3000, () => console.log('Server started on http://localhost:3000'));