const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const path = require('path');

const app = express();
const port = 3000;

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'abcd@123',
    database: 'expense_tracker'
});

db.connect((err) => {
    if (err) throw err;
    console.log('MySQL Connected...');
});

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');

app.get('/', (req, res) => {
    const query = 'SELECT * FROM expenses ORDER BY date DESC';
    db.query(query, (err, results) => {
        if (err) throw err;
        res.render('index', { expenses: results });
    });
});

app.post('/add', (req, res) => {
    const { title, amount, date } = req.body;
    const query = 'INSERT INTO expenses (title, amount, date) VALUES (?, ?, ?)';
    db.query(query, [title, amount, date], (err, result) => {
        if (err) throw err;
        res.redirect('/');
    });
});

app.listen(port, () => {
    console.log(`Expense tracker running on http://localhost:${port}`);
});